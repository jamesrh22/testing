﻿using System;
using System.IO;
using System.Collections.Generic;
using static testing.MovieOrdering;
using static testing.FoodOrdering;

namespace testing
{
    public class Program
    {
        public static void Main()
        {
            
            ConsoleKey inputKey;

            inputKey = Console.ReadKey().Key;
            switch (inputKey)
            {
                case ConsoleKey.F:
                    OrderFoods();
                    break;
                case ConsoleKey.M:
                    OrderMovies();
                    break;
            }
            }
        }
}